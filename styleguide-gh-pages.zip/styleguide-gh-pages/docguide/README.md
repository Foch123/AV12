# Google documentation guide

* [Markdown styleguide](style.md)
* [Best practices](best_practices.md)
* [README files](READMEs.md)
* [Philosophy](philosophy.md)

## See also

* [How to update this guide](https://goto.google.com/doc-guide), for Googlers.
